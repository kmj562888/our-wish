// Firebase Console > 프로젝트 설정 > 내 앱(웹)에서 값을 복사해 넣으세요.
// 이 값은 비밀번호가 아니라 공개 가능한 웹 앱 설정값입니다.
// 실제 개인정보 보호는 Firestore 보안 규칙이 담당합니다.
export const firebaseConfig = {
  apiKey: "",
  authDomain: "",
  projectId: "",
  appId: ""
};
