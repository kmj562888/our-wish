import { firebaseConfig } from './firebase-config.js';

const groups = {
  food: { placeholder: '뭐 먹고 싶어?', memo: '가게, 메뉴, 링크 메모 (선택)', heading: '우리의 먹고 싶은 것', emptyTitle: '먹고 싶은 거 비어있어' },
  place: { placeholder: '어디 가고 싶어?', memo: '장소, 주소, 링크 메모 (선택)', heading: '우리의 가고 싶은 곳', emptyTitle: '가고 싶은 거 비어있어' },
  buy: { placeholder: '뭐 사고 싶어?', memo: '브랜드, 가격, 링크 메모 (선택)', heading: '우리의 사고 싶은 것', emptyTitle: '사고 싶은 거 비어있어' }
};
const $ = id => document.getElementById(id);
const escapeHTML = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const hasFirebase = Boolean(firebaseConfig.apiKey && firebaseConfig.authDomain && firebaseConfig.projectId && firebaseConfig.appId);
const LOCAL_KEY = 'jiji-woojoo-wishes-v1';
let category = 'food';
let hiddenCompleted = false;
let items = [];
let editId = null;
let firebase = null;
let authenticatedUser = null;
let unsubscribe = null;
let busy = false;
let toastTimer = null;

function notify(message) {
  const el = $('toast');
  el.textContent = message;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 2800);
}
function setConnection(message, live=false) {
  $('connection-state').textContent = `● ${message}`;
  $('connection-state').classList.toggle('live', live);
}
function loadLocal() {
  try {
    const parsed = JSON.parse(localStorage.getItem(LOCAL_KEY) || '[]');
    return Array.isArray(parsed) ? parsed.filter(x => groups[x.category] && typeof x.title === 'string') : [];
  } catch { return []; }
}
function saveLocal() { localStorage.setItem(LOCAL_KEY, JSON.stringify(items)); }
function isURL(value) {
  try { const u = new URL(value); return ['http:', 'https:'].includes(u.protocol); } catch {return false;}
}
function memoMarkup(memo) {
  const words = String(memo).split(/(https?:\/\/[^\s]+)/g);
  return words.map(word => isURL(word) ? `<a href="${escapeHTML(word)}" target="_blank" rel="noopener noreferrer">${escapeHTML(word)}</a>` : escapeHTML(word)).join('');
}
function formatDate(obj) {
  if (!obj) return '';
  let dt;
  if (typeof obj.toDate === 'function') dt = obj.toDate();
  else if (typeof obj === 'number') dt = new Date(obj);
  else return '';
  return Number.isNaN(dt.getTime()) ? '' : new Intl.DateTimeFormat('ko-KR', {month:'short',day:'numeric'}).format(dt);
}
function render() {
  for (const [key] of Object.entries(groups)) {
    const count = items.filter(i => i.category === key).length;
    $(`count-${key}`).textContent = `${count}개`;
    const tab = $(`tab-${key}`);
    tab.classList.toggle('is-active', key === category);
    tab.setAttribute('aria-selected', String(key === category));
  }
  $('wishlist-panel').setAttribute('aria-labelledby', `tab-${category}`);
  $('item-title').placeholder = groups[category].placeholder;
  $('item-memo').placeholder = groups[category].memo;
  $('section-heading').textContent = groups[category].heading;
  $('toggle-completed').setAttribute('aria-pressed', String(hiddenCompleted));
  $('toggle-completed').textContent = hiddenCompleted ? '완료 보기' : '완료 숨기기';
  const listed = items.filter(i => i.category === category && !(hiddenCompleted && i.done))
    .sort((a,b) => Number(a.done)-Number(b.done) || timeValue(b.createdAt)-timeValue(a.createdAt));
  $('wish-list').replaceChildren(...listed.map(renderCard));
  $('empty-state').hidden = listed.length > 0;
  $('empty-title').textContent = hiddenCompleted && items.some(i => i.category === category) ? '모두 완료했어 ♡' : groups[category].emptyTitle;
  $('empty-text').textContent = hiddenCompleted && items.some(i => i.category === category) ? '완료 보기를 누르면 다시 볼 수 있어.' : '생각나는 거 하나만 적어봐.';
}
function timeValue(value) {
  return typeof value === 'number' ? value : typeof value?.toMillis === 'function' ? value.toMillis() : 0;
}
function renderCard(item) {
  const outer = document.createElement('article');
  outer.className = `wish-card${item.done ? ' is-done' : ''}`;
  const button = document.createElement('button');
  button.className = 'check-btn';button.type='button';button.setAttribute('aria-label', item.done ? '완료 취소' : '완료 표시');button.textContent='✓';
  button.addEventListener('click', () => toggleDone(item));
  const body = document.createElement('div');body.className='wish-body';
  const title = document.createElement('div');title.className='wish-title';title.textContent=item.title;
  body.appendChild(title);
  if (item.memo) { const memo = document.createElement('p'); memo.className='wish-memo';memo.innerHTML=memoMarkup(item.memo);body.appendChild(memo); }
  const date = formatDate(item.createdAt);
  if (date) { const meta=document.createElement('div');meta.className='wish-meta';meta.textContent=`${date}에 기록`;body.appendChild(meta); }
  const actions=document.createElement('div');actions.className='card-actions';
  const editBtn=document.createElement('button');editBtn.type='button';editBtn.className='icon-btn';editBtn.textContent='✎';editBtn.setAttribute('aria-label', `${item.title} 수정`);editBtn.addEventListener('click',()=>openEdit(item));
  const deleteBtn=document.createElement('button');deleteBtn.type='button';deleteBtn.className='icon-btn';deleteBtn.textContent='×';deleteBtn.setAttribute('aria-label',`${item.title} 삭제`);deleteBtn.addEventListener('click',()=>deleteWish(item));
  actions.append(editBtn,deleteBtn);outer.append(button,body,actions);return outer;
}
function switchCategory(next) {
  category=next;
  render();
  $('item-title').focus({preventScroll:true});
}
async function withBusy(callback) {
  if (busy) return;
  busy=true;$('add-button').disabled=true;
  try{await callback();}catch(err){console.error(err);notify('저장에 실패했어. 다시 시도해 줘.');}finally{busy=false;$('add-button').disabled=false;}
}
async function addWish(e) {
  e.preventDefault();
  const title = $('item-title').value.trim();
  const memo = $('item-memo').value.trim();
  if (!title) return;
  await withBusy(async()=>{
    if(firebase){
      await firebase.addDoc(firebase.collection(firebase.db,'wishes'), {
        title,memo,category,done:false,createdBy:authenticatedUser.uid,
        createdAt:firebase.serverTimestamp(),updatedAt:firebase.serverTimestamp()
      });
    } else {
      items.unshift({id:crypto.randomUUID?.() || String(Date.now()),title,memo,category,done:false,createdAt:Date.now()});
      saveLocal();render();
    }
    $('add-form').reset();$('item-title').focus();notify('위시가 추가됐어 ♡');
  });
}
async function toggleDone(item){
  await withBusy(async()=>{
    if(firebase) await firebase.updateDoc(firebase.doc(firebase.db,'wishes',item.id),{done:!item.done,updatedAt:firebase.serverTimestamp()});
    else {items=items.map(i=>i.id===item.id?{...i,done:!i.done}:i);saveLocal();render();}
    notify(item.done ? '다시 위시리스트에 담았어!' : '하나 이뤘다! ♡');
  });
}
async function deleteWish(item){
  if(!confirm(`“${item.title}” 항목을 삭제할까?`))return;
  await withBusy(async()=>{
    if(firebase) await firebase.deleteDoc(firebase.doc(firebase.db,'wishes',item.id));
    else{items=items.filter(i=>i.id!==item.id);saveLocal();render();}
    notify('삭제했어.');
  });
}
function openEdit(item){
  editId=item.id;$('edit-title').value=item.title;$('edit-memo').value=item.memo||'';
  $('edit-dialog').showModal();
}
async function saveEdit(e){
  e.preventDefault();
  const id=editId, title=$('edit-title').value.trim(),memo=$('edit-memo').value.trim();
  if(!id||!title)return;
  await withBusy(async()=>{
    if(firebase) await firebase.updateDoc(firebase.doc(firebase.db,'wishes',id),{title,memo,updatedAt:firebase.serverTimestamp()});
    else{items=items.map(i=>i.id===id?{...i,title,memo}:i);saveLocal();render();}
    $('edit-dialog').close();editId=null;notify('수정했어 ♡');
  });
}
function normalizeError(e){
  if(e.code==='auth/unauthorized-domain')return 'Firebase 인증 설정에서 GitHub Pages 도메인을 허용해 줘.';
  if(e.code==='auth/popup-blocked')return '팝업이 차단됐어. Safari에서 팝업 허용 후 다시 눌러 줘.';
  if(e.code==='auth/popup-closed-by-user')return '로그인 창이 닫혔어. 다시 시도해 줘.';
  if(e.code==='permission-denied')return '접근 권한이 없어. Firebase 규칙에 두 사람 이메일이 들어갔는지 확인해 줘.';
  return `로그인 또는 데이터 연결 오류가 났어. (${e.code||'연결 확인 필요'})`;
}
async function setupFirebase(){
  try {
    const SDK='https://www.gstatic.com/firebasejs/11.10.0/';
    const [{initializeApp},{getAuth,GoogleAuthProvider,signInWithPopup,onAuthStateChanged,signOut},{getFirestore,collection,doc,addDoc,updateDoc,deleteDoc,onSnapshot,serverTimestamp}] = await Promise.all([
      import(`${SDK}firebase-app.js`),import(`${SDK}firebase-auth.js`),import(`${SDK}firebase-firestore.js`)
    ]);
    const app=initializeApp(firebaseConfig);
    const auth=getAuth(app), db=getFirestore(app), provider=new GoogleAuthProvider();
    firebase={auth,db,collection,doc,addDoc,updateDoc,deleteDoc,onSnapshot,serverTimestamp};
    $('login-overlay').hidden=false;
    $('demo-banner').hidden=true;
    setConnection('로그인 필요');
    $('login-button').addEventListener('click',async()=>{
      $('login-feedback').textContent='';$('login-button').disabled=true;
      try {await signInWithPopup(auth,provider);}
      catch(e){console.error(e);$('login-feedback').textContent=normalizeError(e);}
      finally{$('login-button').disabled=false;}
    });
    $('account-button').addEventListener('click',()=>signOut(auth));
    onAuthStateChanged(auth,user=>{
      if(unsubscribe){unsubscribe();unsubscribe=null;}
      authenticatedUser=user;
      if(!user){items=[];render();$('login-overlay').hidden=false;$('account-button').hidden=true;setConnection('로그인 필요');return;}
      $('login-overlay').hidden=true;$('account-button').hidden=false;setConnection('동기화 중…');
      unsubscribe=onSnapshot(collection(db,'wishes'),snapshot=>{
        items=snapshot.docs.map(d=>({id:d.id,...d.data()}));render();setConnection('함께 동기화 중 ♡',true);
      }, e=>{
        console.error(e);setConnection('접근 권한 확인 필요');
        $('login-overlay').hidden=false;
        $('login-feedback').textContent=normalizeError(e);
      });
    });
  }catch(e){
    console.error(e);setConnection('연결 오류');
    $('demo-banner').hidden=false;
    $('demo-banner').textContent='Firebase 연결 오류가 있어 이 기기에만 저장돼요. 네트워크와 설정을 확인해 줘.';
    items=loadLocal();render();
  }
}

for(const button of document.querySelectorAll('[data-category]')) button.addEventListener('click',()=>switchCategory(button.dataset.category));
$('add-form').addEventListener('submit',addWish);
$('toggle-completed').addEventListener('click',()=>{hiddenCompleted=!hiddenCompleted;render();});
$('edit-form').addEventListener('submit',saveEdit);
$('cancel-edit').addEventListener('click',()=>{$('edit-dialog').close();editId=null;});
$('edit-dialog').addEventListener('close',()=>{editId=null;});
if(hasFirebase){setupFirebase();}
else{items=loadLocal();render();setConnection('체험 모드');}
