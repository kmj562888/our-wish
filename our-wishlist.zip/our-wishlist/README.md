# 우리 위시리스트 ♡ — 지지 × 우주

두 사람만 함께 쓰는 모바일 위시리스트. 먹고 싶은 것 / 가고 싶은 곳 / 사고 싶은 것 탭별 추가, 메모, 링크, 완료 체크, 수정, 삭제가 됩니다.

## 1. 지금 파일을 열었을 때

`firebase-config.js`가 비어 있으면 **체험 모드**로 동작합니다. 이 모드의 기록은 해당 기기 브라우저에만 저장되며 다른 사람과 공유되지 않습니다. 체험 모드에 기록한 내용은 Firebase 공유 모드에 자동으로 옮겨지지 않으니 실제 사용하기 전 Firebase를 연결하세요.

## 2. Firebase 연결 (둘이 같은 목록을 수정하려면 필수)

1. https://console.firebase.google.com/ 에 Google 계정으로 로그인하고 **프로젝트 추가**.
2. 프로젝트에서 **웹 앱 추가 (`</>`)**. 표시되는 `firebaseConfig` 안의 `apiKey`, `authDomain`, `projectId`, `appId` 값을 `firebase-config.js`에 복사합니다.
3. **빌드 → Authentication → 시작하기 → 로그인 방법 → Google** 활성화.
4. **Authentication → Settings → Authorized domains**에 `<GitHub 사용자명>.github.io` 도메인을 추가합니다. `https://`와 경로는 제외.
5. **빌드 → Firestore Database → 데이터베이스 만들기**, 위치를 선택해 생성합니다. 반드시 운영 규칙을 적용하세요.
6. `firestore.rules` 파일을 열고 `FIRST_PERSON@gmail.com`과 `SECOND_PERSON@gmail.com`을 두 사람의 **Google 로그인용 이메일**로 바꿉니다. 전체 내용을 Firebase 콘솔의 **Firestore Database → Rules(규칙)** 에 붙여넣고 **Publish(게시)** 버튼을 누릅니다. 테스트 모드로 열어두지 마세요.
7. 사이트를 열고 **각자 자신의 Google 계정**으로 로그인합니다. 이제 서로 등록한 항목이 실시간으로 같이 보입니다.

> 주의: Firebase의 웹 앱 설정(apiKey 등)은 웹에서 공개되는 값입니다. 개인정보 보호는 `firestore.rules`가 담당합니다. 임의로 `allow read, write: if true`를 사용하지 마세요. GitHub Pages에 올린 **사이트 화면 자체는 공개**될 수 있지만, 위시리스트 내용은 Firebase 보안 규칙에서 허용한 두 사람만 읽거나 쓸 수 있습니다.

## 3. GitHub Pages 게시

1. https://github.com/login 에 로그인한 뒤 우측 상단 `+` → **New repository** → 이름 `our-wishlist` 로 새 저장소를 만듭니다. GitHub에서 Pages를 무료로 쓰려면 저장소 공개가 필요할 수 있습니다.
2. 새 저장소에서 **Add file → Upload files**로 이 압축파일을 **풀어서 나온 파일 전체**(`index.html`, `styles.css`, `app.js`, `firebase-config.js`, `favicon.svg`, `.nojekyll`)를 저장소 루트에 업로드하고 **Commit changes**를 누릅니다. `firestore.rules`도 기록용으로 올릴 수 있으나 이메일이 들어가 있으므로 **공개 저장소에는 올리지 않는 것을 권장합니다**.
3. **Settings → Pages → Build and deployment → Source: Deploy from a branch → Branch: main / (root) → Save**.
4. 사이트 주소는 대체로 `https://<GitHub 사용자명>.github.io/our-wishlist/` 형식입니다. `@gmail.com`이 GitHub 사용자명인 것은 아니므로 GitHub 프로필의 사용자명을 확인하세요.

## 알아두기

- GitHub Pages만 게시하면 **체험 모드**이고 두 기기 간 동기화는 되지 않습니다.
- 이메일만 전달하는 것으로 계정 연결 및 GitHub 업로드가 자동으로 되지 않습니다. 로그인 비밀번호, 인증 코드 또는 GitHub 개인용 토큰은 누구와도 공유하지 마세요.
- 사이트 게시가 완료되더라도 **Firebase 설정과 보안 규칙 게시**는 별도로 필요합니다.
- 2인용 개인 기록에 적합하지만 Firebase/Google 계정은 계정 소유자가 직접 관리해야 합니다.
